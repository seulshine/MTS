package controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import model.dao.ClassAdminDAO;
import model.dao.ClassDAO;
import model.dao.StudentDAO;
import model.dao.TeacherDAO;

public class T_DeleteClassController implements Controller {
	
    private static final Logger log = LoggerFactory.getLogger(DeleteUserController.class);
	
    private ClassDAO classDAO = new ClassDAO();
    private ClassAdminDAO adminDAO = new ClassAdminDAO();
    
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
    	
    	String classId = request.getParameter("classId");
		System.out.println("���� ���̵�" + classId);
		
		String teacherId = request.getParameter("teacherId");
		System.out.println("������ ���̵�" + teacherId);
    
    	String teacher_true = TeacherSessionUtils.getUserFromSession(request.getSession());

		if (teacher_true.equals("Teacher")) {
			try {
				// ������ id������ �̿��ؼ� �ش� ������ class���� �ҷ��´�

				if (request.getMethod().equals("GET")) {

					adminDAO.deleteClassByTeacher(classId, teacherId);
					classDAO.deleteClass(classId);
					return "/su.jsp";
				}

			} catch (Exception e) {
				request.setAttribute("exception", e);
				//return "/fail.jsp";							// forwarding
			}
		}
		
		return null;
    	
		
    }
}

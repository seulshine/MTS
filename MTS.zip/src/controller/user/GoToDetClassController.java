package controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.AClass;
import model.ClassAdmin;
import model.Student;
import model.dao.ClassAdminDAO;
import model.dao.StudentDAO;

public class GoToDetClassController implements Controller {
	private ClassAdminDAO classDAO = new ClassAdminDAO();
	// private StudentDAO studentDAO = new StudentDAO();

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// UserManager manager = UserManager.getInstance();
		String classId = request.getParameter("classId");

		System.out.println("아이디" + classId);

		// String curUserId =
		// UserSessionUtils.getUserFromSession(request.getSession());
		// Student s = studentDAO.premium("alsdbdla");
		//
		// System.out.println(+ s.getName());

		String pre = PremiumSessionUtils.getUserFromSession(request.getSession());
		System.out.println("넘어옴" + pre);

		String student_id = UserSessionUtils.getUserFromSession(request.getSession());
		System.out.println("학생아이디" + student_id);

		String teacher_id = UserSessionUtils.getUserFromSession(request.getSession());
		System.out.println("선생님아이디" + teacher_id);

		String teacher_true = TeacherSessionUtils.getUserFromSession(request.getSession());
		// String teacher_true = "Teacher";
		System.out.println("선생님 맞는지" + teacher_true);

		try {
			// user = manager.findUser(userId); //
			ClassAdmin aclass = classDAO.getClassAdminById(classId);
			if (aclass == null) {
				throw new Exception("존재안함");
			}
			request.setAttribute("aclass", aclass); //
			System.out.println("선생님 수업아이디" + aclass.getTeacher_id());

			if (teacher_true.equals("teacher"))
				return "/ClassDetail_Teacher.jsp"; //
			else
				return "/ClassDetail_general.jsp"; //

		} catch (Exception e) {
			request.setAttribute("exception", e);
			return "/fail.jsp"; // forwarding
		}

	}
}
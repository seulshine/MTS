package controller.user;

//Student_register �л��������� ����ѷ�

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.AClass;
import model.ClassAdmin;
import model.dao.ClassAdminDAO;
import model.dao.ClassCartDAO;
import model.dao.ClassDAO;


public class ApplyClassController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(StudentRegisterUserController.class);
    private ClassAdminDAO admin = new ClassAdminDAO();
    private ClassCartDAO classCartDAO = new ClassCartDAO();

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
     
   
      try {
         // UserManager manager = UserManager.getInstance();
         // manager.create(user);
    	  
    	  System.out.println("����");
         
    		String classId = request.getParameter("classId");
        	
        	String id = UserSessionUtils.getUserFromSession(request.getSession());
        	
        	ClassAdmin a = admin.getClassAdminById(classId);
        	
        	int result = admin.insertClassAdmin(a, id);
			
			int result2 = classCartDAO.deleteClassCart(classId, id);	
			
        	
        	System.out.println("��û" + result);
        	System.out.println("����" + result2);
        	
        return "/su.jsp";      
           
      } catch (Exception e) {     

         return "/fail.jsp"; 
      }
    }
}
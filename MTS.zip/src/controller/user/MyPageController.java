package controller.user;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.AClass;
import model.ClassAdmin;
import model.ClassCart;
import model.Student;
import model.Teacher;
import model.dao.ClassAdminDAO;
import model.dao.ClassCartDAO;
import model.dao.ClassDAO;
import model.dao.StudentDAO;
import model.dao.TeacherDAO;

public class MyPageController implements Controller {
	
	private TeacherDAO teacherDAO = new TeacherDAO();
	private StudentDAO studentDAO = new StudentDAO();
	private ClassCartDAO cartDAO = new ClassCartDAO();
	private ClassAdminDAO DAO = new ClassAdminDAO();
	private ClassDAO adminDAO = new ClassDAO();

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// �α��� ���� Ȯ��

		try {
			// user = manager.findUser(userId); // ����� ���� �˻�
			
			String teacher_true = TeacherSessionUtils.getUserFromSession(request.getSession());	
			
			System.out.println("����");
			
			System.out.println(teacher_true + "�������ΰ�");
			
			if(teacher_true.equals("Teacher")){
				
				String teacher_id = UserSessionUtils.getUserFromSession(request.getSession());
				String pwd = UserSessionUtils.getUserFromSession(request.getSession());	
				Teacher teacher = teacherDAO.getTeacherById(teacher_id, pwd);
				
				List<AClass> admin = adminDAO.getClassListByTeacher(teacher_id);
				
				ArrayList<AClass> ing = new ArrayList<AClass>();
				ArrayList<AClass> end = new ArrayList<AClass>();
				
				for(int i = 0; i < admin.size(); i++){
					if((admin.get(i).getClose()).equals("NOT"))
						ing.add(admin.get(i));
					else
						end.add(admin.get(i));				
				}
				
				request.setAttribute("classListIng", ing);	
				request.setAttribute("classListEnd", end);	
				request.setAttribute("user", teacher);	
				return "/teacher_mypage.jsp";
			}
			
			System.out.println("����2");
			
			String student_id = UserSessionUtils.getUserFromSession(request.getSession());	
			String pwd = UserSessionUtils.getUserFromSession(request.getSession());	
		
			Student student = studentDAO.getStudentById(student_id, pwd);
			
			
			// �������� ����
			System.out.println("�������� ���� ");
			List<ClassAdmin> admin = DAO.getClassAdminByStudent(student_id);
			
			
			
			System.out.println("���ø���Ʈ ");
			// ���ø���Ʈ
			List<ClassCart> cart = cartDAO.getClassCartByStudent_id(student_id);
		
			request.setAttribute("user", student);	
			request.setAttribute("cartList", cart);	
			request.setAttribute("classList", admin);	
			
			for(int i = 0; i < cart.size(); i++){
				System.out.println("��Ʈ�ѷ���" + cart.get(i).getClass_name());
			}
			
			return "/student_mypage.jsp";
 

		} catch (Exception e) {
			request.setAttribute("exception", e);
			return "/fail.jsp"; // forwarding
		}

	}
}

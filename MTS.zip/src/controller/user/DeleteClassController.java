package controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import model.dao.ClassAdminDAO;
import model.dao.StudentDAO;
import model.dao.TeacherDAO;

public class DeleteClassController implements Controller {
	
    private static final Logger log = LoggerFactory.getLogger(DeleteUserController.class);
	
    private ClassAdminDAO admin = new ClassAdminDAO();
    

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
    	
    	
    	String student_id = UserSessionUtils.getUserFromSession(request.getSession());	
    	String classId = request.getParameter("classId");
    	
    	System.out.println("�л����̵�" + student_id);
    	System.out.println("���� ���̵�" + classId);
    	
    	int result = admin.deleteClass(classId, student_id);
    	
    	
    	System.out.println("����" + result);
		

		return "/Loading.jsp";		
    }
}

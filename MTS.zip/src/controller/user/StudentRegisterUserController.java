package controller.user;

//Student_register �л��������� ����ѷ�

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Student;
import model.dao.StudentDAO;
import model.service.ExistingUserException;

public class StudentRegisterUserController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(StudentRegisterUserController.class);
   private StudentDAO studentDAO = new StudentDAO();

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
      Student user = new Student(
         request.getParameter("user_id"),
         request.getParameter("user_name"),
         request.getParameter("mbpw"),
         request.getParameter("tel_h"),
         request.getParameter("user_age"),
         request.getParameter("gender")
         ,"N");
        log.debug("Create User : {}", user);

      try {
         // UserManager manager = UserManager.getInstance();
         // manager.create(user);
         
         if (studentDAO.existingUser(user.getStudent_id()) == true) {
            throw new ExistingUserException(user.getStudent_id() + "�� �����ϴ� ���̵��Դϴ�.");
         }
         studentDAO.insertStudent(user); // �л� ���� ����
        return "/loginForm.jsp";      // * ���� �� ȭ������ redirect
           
      } catch (Exception e) {      // ���� �߻� �� ȸ������ form���� forwarding
//         request.setAttribute("registerFailed", true);
//         request.setAttribute("exception", e);
//         request.setAttribute("user", user);
         return "/Join.jsp"; // * ȸ������ ������ ������
      }
    }
}
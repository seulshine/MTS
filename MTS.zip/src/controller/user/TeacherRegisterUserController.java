package controller.user;

//Student_register �л��������� ����ѷ�

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Student;
import model.Teacher;
import model.dao.StudentDAO;
import model.dao.TeacherDAO;
import model.service.ExistingUserException;

public class TeacherRegisterUserController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(StudentRegisterUserController.class);
   private TeacherDAO teacherDAO = new TeacherDAO();

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
      Teacher user = new Teacher(
         request.getParameter("user_id"),
         request.getParameter("user_name"),
         request.getParameter("mbpw"),
         request.getParameter("tel_h"),
         request.getParameter("user_age"),
         request.getParameter("gender"),
         request.getParameter("email"));
        log.debug("Create User : {}", user);

      try {
         // UserManager manager = UserManager.getInstance();
         // manager.create(user);
         
         if (teacherDAO.existingUser(user.getTeacher_id()) == true) {
            throw new ExistingUserException(user.getTeacher_id() + "�� �����ϴ� ���̵��Դϴ�.");
         }
         teacherDAO.insertTeacher(user); // �л� ���� ����
        return "/LoginT.jsp";  
           
      } catch (Exception e) {      // ���� �߻� �� ȸ������ form���� forwarding

         return "/JoinT.jsp"; 
      }
    }
}
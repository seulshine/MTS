package controller.user; 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller; 
import model.dao.StudentDAO;
public class IsLoginedForPremiumPayController implements Controller{
	 @Override
	   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	      try {
	         
	         String userID = UserSessionUtils.getUserFromSession(request.getSession());   
	         
	         if(userID == null || userID.isEmpty()) {
	            request.setAttribute("isNotLogined", "true");
	            return "/LoginMenu.jsp";
	         }  
	         return "/PremiumPay.jsp";

	      } catch (Exception e) {
	         request.setAttribute("exception", e);
	         return "/fail.jsp"; // forwarding
	      }
	   }
}

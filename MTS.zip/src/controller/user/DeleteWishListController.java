package controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.dao.ClassCartDAO;



public class DeleteWishListController implements Controller{
	
	private ClassCartDAO classCartDAO = new ClassCartDAO();

	 @Override
	   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {		
    	
		
		//System.out.println("ī�װ���" + category);
		
		try {
			// user = manager.findUser(userId);	// ����� ���� �˻�
			
			
			String classId = request.getParameter("classId");
			String id = UserSessionUtils.getUserFromSession(request.getSession());
				
			int result = classCartDAO.deleteClassCart(classId, id);	
			
			System.out.println("�����Ϸ�"+result) ;
			
			
			return "/su.jsp"; // ���ø���Ʈ ������� �̵�
			
								// ��ٱ��Ϸ� �̵�
			
		} catch (Exception e) {			
			request.setAttribute("exception", e);			
			return "/fail.jsp";							// forwarding
		}			
						
	       
    }

}

package controller.user;

import javax.servlet.http.HttpSession;

public class PremiumSessionUtils {
    public static final String PREMIUM_SESSION_KEY = "premium";

    public static String getUserFromSession(HttpSession session) {
        String premium = (String)session.getAttribute(PREMIUM_SESSION_KEY);
        return premium;
    }

  
    /*
     public static boolean isSameUser(HttpSession session, User user) {
        if (!isLogined(session)) {
            return false;
        }
        if (user == null) {
            return false;
        }
        return user.isSameUser(getUserFromSession(session));
    }
    */
}
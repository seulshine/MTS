package controller.user;

import javax.servlet.http.HttpSession;

public class PwdSessionUtils {
    public static final String PWD_SESSION_KEY = "pwd";

    public static String getUserFromSession(HttpSession session) {
        String pwd = (String)session.getAttribute(PWD_SESSION_KEY);
        return pwd;
    }


    /*
     public static boolean isSameUser(HttpSession session, User user) {
        if (!isLogined(session)) {
            return false;
        }
        if (user == null) {
            return false;
        }
        return user.isSameUser(getUserFromSession(session));
    }
    */
}
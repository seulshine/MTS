package controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Controller;
import model.AClass;
import model.dao.ClassDAO;
import model.dao.StudentDAO;

public class PremiumPayController implements Controller {
   private StudentDAO studentDAO = new StudentDAO();

   @Override
   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
      try {
    	  System.out.println("PremiumPayController ���� " );
         String userID = UserSessionUtils.getUserFromSession(request.getSession());   
         
         if(userID == null || userID.isEmpty()) {
            request.setAttribute("isNotLogined", "true");
            return "/loginform.jsp";
         } else { 
            System.out.println("userID " + userID);
            int preUpResult = studentDAO.updatePremium(userID);
            
            if(preUpResult == 1) {
               request.setAttribute("success", "done");
               HttpSession session = request.getSession();
               session.removeAttribute(PremiumSessionUtils.PREMIUM_SESSION_KEY);
               session.setAttribute(PremiumSessionUtils.PREMIUM_SESSION_KEY, "PREMIUM");
            }
         }
         return "/Loading.jsp";

      } catch (Exception e) {
         request.setAttribute("exception", e);
         return "/fail.jsp"; // forwarding
      }
   }

}
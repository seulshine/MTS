package controller;

import java.util.HashMap;
import my_class.*;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.user.*;

public class RequestMapping {
    private static final Logger logger = LoggerFactory.getLogger(DispatcherServlet.class);
    
    // �� ��û uri�� ���� controller ��ü�� ������ HashMap ����
    private Map<String, Controller> mappings = new HashMap<String, Controller>();

    public void initMapping() {
       // �� uri�� �����Ǵ� controller ��ü�� ���� �� ����
        mappings.put("/", new ForwardController("index.jsp"));
        /*mappings.put("/user/login", new StudentLoginController());*/
        mappings.put("/user/Join", new StudentRegisterUserController());
        mappings.put("/user/Join/teacher", new TeacherRegisterUserController());
        /*mappings.put("/register_teacher", new TeacherRegisterUserController());*/
        mappings.put("/user/register/form", new ForwardController("/Join.jsp"));
        mappings.put("/user/review", new ReviewClassController());
        mappings.put("/user/register/form2", new ForwardController("/JoinT.jsp"));
        mappings.put("/user/joinmenu", new ForwardController("/JoinMenu.jsp"));
        mappings.put("/user/wishlist/form2", new ForwardController("/WishList.jsp"));
        mappings.put("/user/loading", new ForwardController("/Loading.jsp"));
        mappings.put("/user/loading/login", new ForwardController("/Loading_login.jsp"));
        mappings.put("/user/loginform", new ForwardController("/LoginMenu.jsp"));
        mappings.put("/user/classdetail", new ForwardController("/ClassDetail_general.jsp"));
        mappings.put("/premiumPay", new IsLoginedForPremiumPayController()); 
        mappings.put("/premiumPay/pay", new PremiumPayController()); 
        mappings.put("/user/myPage", new MyPageController());
        mappings.put("/user/wishlist", new WishListController()); // ���ø���Ʈ 
        mappings.put("/user/delete/class", new DeleteClassController());
        mappings.put("/", new ForwardController("index.jsp"));
        /*mappings.put("/user/login", new StudentLoginController());*/
        mappings.put("/user/Join", new StudentRegisterUserController());
        mappings.put("/user/Join/teacher", new TeacherRegisterUserController());
        /*mappings.put("/register_teacher", new TeacherRegisterUserController());*/
        mappings.put("/user/register/form", new ForwardController("/Join.jsp"));
        mappings.put("/user/register/form2", new ForwardController("/JoinT.jsp"));
        mappings.put("/user/myPage", new MyPageController());
        mappings.put("/user/wishlist", new WishListController()); // ���ø���Ʈ
        mappings.put("/user/wishlistDelete", new DeleteWishListController()); // ���ø���Ʈ
        //mappings.put("/user/main/teaher", new ForwardController("/Join.jsp"));
        mappings.put("/user/main/student", new ForwardController("/loginForm.jsp"));
        mappings.put("/user/register/form/teacher", new ForwardController("/Join_teacher.jsp"));
        mappings.put("/user/login", new StudentLoginController());
        mappings.put("/user/login/teacher", new TeacherLoginController());
        mappings.put("/user/class_info", new MainController());
        mappings.put("/user/classdetail", new GoToDetClassController());
        mappings.put("/user/review", new ReviewClassController());
        mappings.put("/search", new SearchAtMainBarController());
        mappings.put("/user/update/form", new UpdateUserController());
        mappings.put("/user/update", new UpdateUserController());
        mappings.put("/user/delete", new DeleteUserController());
        mappings.put("/user/delete/class", new DeleteClassController());
        mappings.put("/user/apply", new ApplyClassController());
        mappings.put("/search", new SearchAtMainBarController());
        mappings.put("/search/category", new SearchWithCategoryController());
        mappings.put("/search/category/option", new SearchWithCategoryAsOptionController());
        mappings.put("/user/wishlistDelete", new DeleteWishListController()); // ���ø���Ʈ 
        //mappings.put("/user/main/teaher", new ForwardController("/Join.jsp"));
        mappings.put("/user/main/student", new ForwardController("/loginForm.jsp"));
        mappings.put("/user/register/review", new ForwardController("/ReviewRegister.jsp"));
        mappings.put("/user/main/teacher", new ForwardController("/LoginT.jsp"));
        mappings.put("/user/register/form/teacher", new ForwardController("/Join_teacher.jsp"));
        mappings.put("/user/login", new StudentLoginController());
        mappings.put("/user/login/teacher", new TeacherLoginController());
        mappings.put("/user/class_info", new MainController());
        mappings.put("/user/close_class", new T_CloseClassController()); //����
        mappings.put("/user/delete_class", new T_DeleteClassController()); //����
        logger.info("Initialized Request Mapping!");
        mappings.put("/user/class_detail", new GoToDetClassController());
        mappings.put("/search", new SearchAtMainBarController()); 
        mappings.put("/search/category", new SearchWithCategoryController()); 
        mappings.put("/search/category/option", new SearchWithCategoryAsOptionController()); 
        
        mappings.put("/user/update", new UpdateUserController());
        mappings.put("/user/delete", new DeleteUserController());
        logger.info("Initialized Request Mapping!");
    }

    public Controller findController(String uri) {   
       // �־��� uri�� �����Ǵ� controller ��ü�� ã�� ��ȯ
        return mappings.get(uri);
    }
}








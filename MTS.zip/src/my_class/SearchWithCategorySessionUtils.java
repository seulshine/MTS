package my_class;
import javax.servlet.http.HttpSession;
public class SearchWithCategorySessionUtils {
	 public static final String CATEGORY_SESSION_KEY = "category";
	 public static final String TEACHERNAME_SESSION_KEY = "teacherName";
	 public static final String TITLE_SESSION_KEY = "title";

	    public static String getCategoryFromSession(HttpSession session) {
	        String category = (String)session.getAttribute(CATEGORY_SESSION_KEY);
	        return category;
	    }
	    
	    public static String getTeacherNameFromSession(HttpSession session) {
	        String teacherName = (String)session.getAttribute(TEACHERNAME_SESSION_KEY);
	        return teacherName;
	    }
	    
	    public static String getTitleFromSession(HttpSession session) {
	        String title = (String)session.getAttribute(TITLE_SESSION_KEY);
	        return title;
	    }

	    
}

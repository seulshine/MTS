package my_class;

import java.util.ArrayList;
import java.util.List;

//Ȥ�� ���� �� ����Ʈ ��
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Controller;
//import controller.user.UserSessionUtils;
import model.AClass;
import model.ClassAdmin;
import model.dao.ClassAdminDAO;
import model.dao.ClassDAO;

public class SearchWithCategoryAsOptionController implements Controller {
	private ClassDAO classDAO = new ClassDAO();
	private ClassAdminDAO classadminDAO = new ClassAdminDAO();

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			String category = SearchWithCategorySessionUtils.getCategoryFromSession(request.getSession());
			String teacher_name = SearchWithCategorySessionUtils.getTeacherNameFromSession(request.getSession());
			String title = SearchWithCategorySessionUtils.getTitleFromSession(request.getSession());
			String region = request.getParameter("region");
			System.out.println( category );
			System.out.println( teacher_name );
			System.out.println( title );
			 
			String option = request.getParameter("search_option_value");  
			
			// ��Ʈ�� ��üũ ��ſ� ������ƿ�� �޼ҵ� �����ؼ�
 
			
			 
			    if (category != null && region.equals("�����ϼ���") && (  teacher_name == null  &&   title == null) ) {
				
				System.out.println("ī�װ���+�ɼǰ˻�" + category + " " + option);
				 
				List<AClass> categoryClassList = classDAO.getClassList(category, option);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList);  

			} else if (category != null && !region.equals("�����ϼ���") && teacher_name == null  &&   title == null) {
				System.out.println("ī�װ���+�ɼ�+�����˻�" + category + " " + option);
				System.out.println("region�� ���̿��� " + region);
				List<AClass> categoryClassList = classDAO.getClassList(category, region, option);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList);  

			} else if (region.equals("�����ϼ���") &&   teacher_name != null  &&   title == null)  {
				
				System.out.println("�������̸�+�ɼǰ˻�" + teacher_name + " " + option); 
				List<AClass> categoryClassList = classDAO.getClassListByTeacherName(teacher_name, option);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList);  

			} else if (!region.equals("�����ϼ���") && teacher_name != null  &&   title == null) {
				System.out.println("�������̸�+�ɼ�+�����˻�" + teacher_name + " " + option);
				System.out.println("region�� ���̿��� " + region);
			
				List<AClass> categoryClassList = classDAO.getClassListByTeacherName(teacher_name, region, option);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList);  

			} else if (region.equals("�����ϼ���") &&   teacher_name == null  &&   title != null)  {
				
				System.out.println("�����̸�+�ɼ� �˻�" + title + " " + option);
				List<AClass> categoryClassList = classDAO.getClassListByClassName(title, option);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList);  

			} else if (!region.equals("�����ϼ���") && teacher_name == null  &&   title != null) {
				System.out.println("�����̸�+�ɼ�+�����˻�" + title + " " + option);
				System.out.println("region�� ���̿��� " + region);
				
				List<AClass> categoryClassList = classDAO.getClassListByClassName(title, region, option);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList); 

			}
			return "/SearchResult.jsp";

		} catch (Exception e) {
			request.setAttribute("exception", e);
			System.out.println(e);
			return "/fail.jsp"; // forwarding
		}

	}
}

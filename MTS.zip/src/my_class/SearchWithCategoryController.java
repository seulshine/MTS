package my_class;

import java.util.ArrayList;
import java.util.List;

//Ȥ�� ���� �� ����Ʈ ��
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Controller;
import controller.user.UserSessionUtils;
//import controller.user.UserSessionUtils;
import model.AClass;
import model.ClassAdmin;
import model.dao.ClassAdminDAO;
import model.dao.ClassDAO;

public class SearchWithCategoryController implements Controller {

	private ClassDAO classDAO = new ClassDAO();
	private ClassAdminDAO classadminDAO = new ClassAdminDAO();

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			String category = request.getParameter("cateName");

			// ���ǿ� ī�װ��� ����
			HttpSession session = request.getSession(); 
			session.setAttribute(SearchWithCategorySessionUtils.CATEGORY_SESSION_KEY, category);
			session.removeAttribute(SearchWithCategorySessionUtils.TEACHERNAME_SESSION_KEY );
			session.removeAttribute(SearchWithCategorySessionUtils.TITLE_SESSION_KEY );
			if (category.isEmpty()) {
				System.out.println("error");
			} else {
				List<AClass> categoryClassList = classDAO.getClassList(category);

				request.setAttribute("SearchResultSize", categoryClassList.size());
				request.setAttribute("ClassList", categoryClassList);

				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin;
				for (int i = 0; i < categoryClassList.size(); i++) {

					classadmin = classadminDAO
							.getClassAdminById(Integer.toString(categoryClassList.get(i).getClass_id()));
					classadminList.add(classadmin);

				}
				request.setAttribute("ClassAdminList", classadminList);

			}
			return "/SearchResult.jsp";

		} catch (Exception e) {
			request.setAttribute("exception", e);
			return "/fail.jsp"; // forwarding
		}

	}

}

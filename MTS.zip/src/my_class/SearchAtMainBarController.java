package my_class;

import java.util.ArrayList;
import java.util.List;

//Ȥ�� ���� �� ����Ʈ ��
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import controller.Controller;
//import controller.user.UserSessionUtils;
import model.AClass;
import model.ClassAdmin;
import model.dao.ClassAdminDAO;
import model.dao.ClassDAO;
//import model.service.UserManager;

public class SearchAtMainBarController implements Controller {

	private ClassDAO classDAO = new ClassDAO();
	private ClassAdminDAO classadminDAO = new ClassAdminDAO();
	 @Override
	   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception { 
		 try { 
			String search_option = request.getParameter("search_option");
			String search_value = request.getParameter("search_value");  
			
			if (search_option.isEmpty()){
				System.out.println("error");
			}else if (search_option.equals("2")) { 
				// ���ǿ� ī�װ��� ����
				HttpSession session = request.getSession();
				session.setAttribute(SearchWithCategorySessionUtils.TEACHERNAME_SESSION_KEY, search_value);
				session.removeAttribute(SearchWithCategorySessionUtils.CATEGORY_SESSION_KEY );
				session.removeAttribute(SearchWithCategorySessionUtils.TITLE_SESSION_KEY );
				List<AClass> teacherNameClassList = classDAO.getClassListByTeacherName(search_value);
				
				request.setAttribute("SearchResultSize", teacherNameClassList.size());  
				request.setAttribute("ClassList", teacherNameClassList);  
				
				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin; 
				for(int i = 0; i < teacherNameClassList.size(); i++) {
					
					classadmin = classadminDAO.getClassAdminById(Integer.toString(teacherNameClassList.get(i).getClass_id()));
					classadminList.add(classadmin); 
					
				}
				request.setAttribute("ClassAdminList", classadminList);  
				
			} else if (search_option.equals("1")) {  
				
				// ���ǿ� ī�װ��� ����
				HttpSession session = request.getSession();
				session.setAttribute(SearchWithCategorySessionUtils.TITLE_SESSION_KEY, search_value); 
				session.removeAttribute(SearchWithCategorySessionUtils.CATEGORY_SESSION_KEY );
				session.removeAttribute(SearchWithCategorySessionUtils.TEACHERNAME_SESSION_KEY );
				
				List<AClass> classNameClassList = (List<AClass>) classDAO.getClassListByClassName(search_value);  
				request.setAttribute("SearchResultSize", classNameClassList.size());  
				request.setAttribute("ClassList", classNameClassList); 
				
				List<ClassAdmin> classadminList = new ArrayList<ClassAdmin>();
				ClassAdmin classadmin; 
				for(int i = 0; i < classNameClassList.size(); i++) {
					
					classadmin = classadminDAO.getClassAdminById(Integer.toString(classNameClassList.get(i).getClass_id()));
					classadminList.add(classadmin); 
					
				}
				request.setAttribute("ClassAdminList", classadminList);  
				
			}  
			return "/SearchResult.jsp";

			} catch (Exception e) { 
				request.setAttribute("exception", e);
				return "/fail.jsp"; // forwarding
			}

	}

}

package model;
/**
 * ����� ������ ���� �ʿ��� ������ Ŭ����. USERINFO ���̺��� ������
 */
public class Student {
   
      private String student_id = null;         
      private String name = null;      
      private String pwd;         
      private String phone;   
      private int age;         
      private String gender = null;      
      private String premium = null;
      
      public Student() { }      // �⺻ ������
      
      public Student(String student_id, String name, String pwd, String phone, String age, String gender, String premium) {

            this.student_id = student_id;         
            this.name = name;      
            this.pwd = pwd;         
            this.phone = phone;   
            this.age = Integer.parseInt(age);         
            this.gender = gender;      
            this.premium = premium;
      }
      
   public String getStudent_id() {
      return student_id;
   }
   public void setStudent_id(String student_id) {
      this.student_id = student_id;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getPwd() {
      return pwd;
   }

   public int getAge() {
      return age;
   }
   public void setAge(int age) {
      this.age = age;
   }
   public String getGender() {
      return gender;
   }
   public void setGender(String gender) {
      this.gender = gender;
   }
   public String getPremium() {
      return premium;
   }
   public void setPremium(String premium) {
      this.premium = premium;
   }   
      /* ��й�ȣ �˻� */
   public boolean matchPassword(String password) {
      if (password == null) {
         return false;
      }
      return this.pwd.equals(password);
   }

public String getPhone() {
   return phone;
}

public void setPhone(String phone) {
   this.phone = phone;
}

public void setPwd(String pwd) {
   this.pwd = pwd;
}


      
     

}
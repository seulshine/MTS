package model;
/**
 * ����� ������ ���� �ʿ��� ������ Ŭ����. USERINFO ���̺��� ������
 */
public class ClassAdmin {
      private int class_id;         // �й�
      private String class_name = null;      // ����
      private String region = null;         // ��ȣ 
      private String category = null;   // �л� ����ó
      private int max_student;         // �г�
      private String created_date;      // ������
      private int class_order;      // �����ϼ�
      private String close = null;      // ������������
      private int student_num;         // �����ο�
      private int class_age;
      
      //class_admin ���̺�
      private String student_id = null;      
      private String teacher_id = null;   
      private String review = null;         
      private int rate;
      
      //teacher ���̺�
      private String teacher_name = null;
      
      public ClassAdmin() { }      // �⺻ ������
      
      public ClassAdmin(String class_id, String student_id, String teacher_id) 
      {
         this.class_id = Integer.parseInt(class_id); 
         this.student_id = student_id;   
         this.teacher_id = teacher_id;   
         
      }

      public ClassAdmin(String class_id, String class_name, String region, String category, String max_student, 
            String created_date, String class_order, String close, String student_num, String class_age,
            String student_id, String teacher_id, String review, String rate, String teacher_name)
      {
            this.class_id = Integer.parseInt(class_id);      // �й�
            this.class_name = class_name;   // ����
            this.region = region;         // ��ȣ 
            this.category = category;   // �л� ����ó
            this.max_student =  Integer.parseInt(max_student);         // �г�
            this.created_date = created_date;      // ������
            this.class_order =  Integer.parseInt(class_order);   // �����ϼ�
            this.close = close;      // ������������
            this.student_num =  Integer.parseInt(student_num);         // �����ο�
            this.class_age = Integer.parseInt(class_age);   
            
            
            //admin���̺�
            this.student_id = student_id;      
            this.teacher_id = teacher_id;   
            this.review = review;         
            this.rate = Integer.parseInt(class_id);   
            
            this.teacher_name = teacher_name;
      }
      
      public String getClass_name() {
      return class_name;
   }
   public void setClass_name(String class_name) {
      this.class_name = class_name;
   }
   public String getRegion() {
      return region;
   }
   public void setRegion(String region) {
      this.region = region;
   }
   public String getCategory() {
      return category;
   }
   public void setCategory(String category) {
      this.category = category;
   }
   public int getMax_student() {
      return max_student;
   }
   public void setMax_student(int max_student) {
      this.max_student = max_student;
   }
   public String getCreated_date() {
      return created_date;
   }
   public void setCreated_date(String created_date) {
      this.created_date = created_date;
   }
   public int getClass_order() {
      return class_order;
   }
   public void setClass_order(int class_order) {
      this.class_order = class_order;
   }
   public String getClose() {
      return close;
   }
   public void setClose(String close) {
      this.close = close;
   }
   public int getStudent_num() {
      return student_num;
   }
   public void setStudent_num(int student_num) {
      this.student_num = student_num;
   }
   public int getClass_age() {
      return class_age;
   }
   public void setClass_age(int class_age) {
      this.class_age = class_age;
   }
   public String getTeacher_name() {
      return teacher_name;
   }
   public void setTeacher_name(String teacher_name) {
      this.teacher_name = teacher_name;
   }

   public int getClass_id() {
      return class_id;
   }
   public void setClass_id(int class_id) {
      this.class_id = class_id;
   }
   public String getStudent_id() {
      return student_id;
   }
   public void setStudent_id(String student_id) {
      this.student_id = student_id;
   }
   public String getTeacher_id() {
      return teacher_id;
   }
   public void setTeacher_id(String teacher_id) {
      this.teacher_id = teacher_id;
   }
   public String getReview() {
      return review;
   }
   public void setReview(String review) {
      this.review = review;
   }
   public int getRate() {
      return rate;
   }
   public void setRate(int rate) {
      this.rate = rate;
   }      
      
      
}
package model;
/**
 * ����� ������ ���� �ʿ��� ������ Ŭ����. USERINFO ���̺��� ������
 */
public class Teacher {
   private String teacher_id = null;   
   private String name = null;      
   private String pwd = null;         
   private String phone = null;   
   private int age;         
   private String gender = null;      
   private String info = null;
   private String email = null;   
   
   public Teacher() { }
   
   public Teacher(String teacher_id, String name, String pwd, String phone, String age, String gender, String email) {

         this.teacher_id = teacher_id;         
         this.name = name;      
         this.pwd = pwd;         
         this.phone = phone;
         this.age = Integer.parseInt(age);         
         this.gender = gender;    
         this.email = email;   
   }
      
      public String getTeacher_id() {
      return teacher_id;
   }
   public void setTeacher_id(String teacher_id) {
      this.teacher_id = teacher_id;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getPwd() {
      return pwd;
   }
   public void setPwd(String pwd) {
      this.pwd = pwd;
   }

   
   public String getPhone() {
      return phone;
   }

   public void setPhone(String phone) {
      this.phone = phone;
   }

   public int getAge() {
      return age;
   }

   public void setAge(int age) {
      this.age = age;
   }

   public String getGender() {
      return gender;
   }
   public void setGender(String gender) {
      this.gender = gender;
   }
   public String getInfo() {
      return info;
   }
   public void setInfo(String info) {
      this.info = info;
   }
   public String getEmail() {
      return email;
   }
   public void setEmail(String email) {
      this.email = email;
   }
   
   /* ��й�ȣ �˻� */
   public boolean matchPassword(String password) {
      if (password == null) {
         return false;
      }
      return this.pwd.equals(password);
   }
}